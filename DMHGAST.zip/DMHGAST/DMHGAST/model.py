import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.modules.module import Module
from .GAT import GATConv
from.preprocess import fix_seed
import math

class EnhancedDecoder(nn.Module):
    def __init__(self, out_features, in_features):
        super().__init__()
        self.gat_dec = GATConv(out_features, 256, add_self_loops=False)
        self.fc = nn.Linear(256, in_features)
    def forward(self, x, edge_index):
        x = F.elu(self.gat_dec(x, edge_index))
        return self.fc(x)
class MultiHeadRouting(nn.Module):
    def __init__(self, n_heads=4, hidden_dim=256):
        super().__init__()
        self.n_heads = n_heads
        self.attention_layers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(hidden_dim * 2, 32),
                nn.ReLU(),
                nn.Linear(32, 1)
            ) for _ in range(n_heads)
        ])

    def forward(self, x, hop_features):
        all_weights = []
        for att in self.attention_layers:
            expanded_x = x.unsqueeze(0).expand(hop_features.size(0), -1, -1)
            energy = att(torch.cat([expanded_x, hop_features], dim=-1)).squeeze(-1)
            weights = F.softmax(energy, dim=0)  # [Hops, N]
            all_weights.append(weights)
        combined_weights = torch.stack(all_weights, dim=0).mean(dim=0)  # [Hops, N]
        return combined_weights.permute(1, 0)  # [N, Hops]
class DynamicMultiHopGAT(nn.Module):
    """带残差连接的多跳GAT"""
    def __init__(self, in_features, out_features, hops=3, heads=4):
        super().__init__()
        self.hops = hops
        self.res_weights = nn.Parameter(torch.ones(hops))
        self.hop_layers = nn.ModuleList()
        current_dim = in_features
        for _ in range(hops):
            self.hop_layers.append(GATConv(current_dim, out_features, heads=1, concat=False))
            current_dim = out_features
        self.router = MultiHeadRouting(n_heads=heads,hidden_dim=out_features)
        self.res_proj = nn.Linear(in_features, out_features) if in_features != out_features else None
    def forward(self, x, edge_index):
        residual = x
        if self.res_proj is not None:
            residual = self.res_proj(residual)
        hop_features = []
        for layer in self.hop_layers:
            x = F.elu(layer(x, edge_index))
            hop_features.append(x)
        route_weights = self.router(residual, torch.stack(hop_features))  # [N, Hops]
        weighted_features = torch.stack([
            route_weights[:, i].unsqueeze(-1) * hop_features[i]
            for i in range(self.hops)
        ]).sum(dim=0)

        return residual + weighted_features


class SpatialPositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=10000):
        super().__init__()
        self.d_model = d_model // 2
        self.max_len = max_len
        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, self.d_model, 2) * (-math.log(10000.0) / self.d_model))
        pe = torch.zeros(1, max_len, self.d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)

    def forward(self, coords):
        coords_x, coords_y = coords[:, 0], coords[:, 1]
        scale_x = coords_x.max() - coords_x.min()
        norm_x = ((coords_x - coords_x.min()) / scale_x * (self.max_len - 1)).long()
        scale_y = coords_y.max() - coords_y.min()
        norm_y = ((coords_y - coords_y.min()) / scale_y * (self.max_len - 1)).long()
        pe_x = self.pe[:, norm_x].squeeze(0)
        pe_y = self.pe[:, norm_y].squeeze(0)
        combined_pe = torch.cat([pe_x, pe_y], dim=-1)
        return combined_pe

class Discriminator(nn.Module):
    def __init__(self, n_h):
        super(Discriminator, self).__init__()
        self.f_k = nn.Bilinear(n_h, n_h, 1)

        for m in self.modules():
            self.weights_init(m)

    def weights_init(self, m):
        if isinstance(m, nn.Bilinear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)

    def forward(self, c, h_pl, h_mi, s_bias1=None, s_bias2=None):
        c_x = c.expand_as(h_pl)
        sc_1 = self.f_k(h_pl, c_x)
        sc_2 = self.f_k(h_mi, c_x)
        if s_bias1 is not None:
            sc_1 += s_bias1
        if s_bias2 is not None:
            sc_2 += s_bias2
        logits = torch.cat((sc_1, sc_2), 1)
        return logits
    
class AvgReadout(nn.Module):
    def __init__(self):
        super(AvgReadout, self).__init__()
    def forward(self, emb, mask=None):
        vsum = torch.mm(mask, emb)
        row_sum = torch.sum(mask, 1)
        row_sum = row_sum.expand((vsum.shape[1], row_sum.shape[0])).T
        global_emb = vsum / row_sum
        return F.normalize(global_emb, p=2, dim=1) 


class Encoder(Module):
     def __init__(self, in_features, out_features, graph_neigh, dropout=0.0, act=F.relu, random_seed=2025):
        super(Encoder, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.random_seed = random_seed
        fix_seed(self.random_seed)
        self.graph_neigh = graph_neigh
        self.dropout = dropout
        self.act = act
        self.random_seed = random_seed
        num_hidden = 256
        hops=3
        fix_seed(self.random_seed)
        self.pos_encoder = SpatialPositionalEncoding(in_features)
        self.gat1 = DynamicMultiHopGAT( self.in_features, num_hidden, hops=hops)
        self.gat2 = DynamicMultiHopGAT(num_hidden, out_features, hops=hops)
        self.decoder = EnhancedDecoder(out_features, self.in_features)
        self.read = AvgReadout()
        self.disc = Discriminator(self.out_features)
        self.sigm = nn.Sigmoid()

     def forward(self, feat, feat_a, edge_index,spatial_coords):
        pos_emb = self.pos_encoder(spatial_coords)
        feat = feat + pos_emb
        feat_a = feat_a + pos_emb
        h1 = self.gat1(feat, edge_index)
        h2 = self.gat2(h1, edge_index)
        h3 = self.decoder(h2, edge_index)
        h1_a = self.gat1(feat_a, edge_index)
        h2_a = self.gat2(h1_a, edge_index)
        g = self.read(h2, self.graph_neigh)
        g = self.sigm(g)
        g_a = self.read(h2_a, self.graph_neigh)
        g_a = self.sigm(g_a)
        ret = self.disc(g, h2, h2_a)
        ret_a = self.disc(g_a, h2_a, h2)
        return h3, ret, ret_a, h2, h2_a


